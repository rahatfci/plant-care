import 'package:cloud_firestore/cloud_firestore.dart';

class UserController {
  CollectionReference reference =
      FirebaseFirestore.instance.collection('users');
}
