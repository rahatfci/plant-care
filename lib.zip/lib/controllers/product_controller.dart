import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/product_model.dart';

class ProductController {
  static final CollectionReference reference =
      FirebaseFirestore.instance.collection('products');

  static Stream<List<Product>> allProduct() {
    return reference.snapshots().map(
        (event) => event.docs.map((e) => Product.fromJson(e.data())).toList());
  }
}
