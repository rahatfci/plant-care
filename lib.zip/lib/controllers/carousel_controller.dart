import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../models/carousel_model.dart';

class CarouselControllerCustom {
  static Stream<List<CarouselCustom>>? all;
  static Stream<List<CarouselCustom>> allCarousel(List<Uint8List?> byteImages) {
    final CollectionReference reference =
        FirebaseFirestore.instance.collection('carousel');

    Stream<List<CarouselCustom>>? all = reference.snapshots().map((event) =>
        event.docs.map((e) => CarouselCustom.fromJson(e.data())).toList());
    return all;
  }

  static List<Uint8List?> byteImages() {
    List<Uint8List?> images = [];
    all!.map((event) {
      event.map((e) async {
        images.add(
            await FirebaseStorage.instance.ref().child(e.imgPath).getData());
      });
    });
    return images;
  }
}
