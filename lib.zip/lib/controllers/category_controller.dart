import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/category_model.dart';

class CategoryController {
  static final CollectionReference reference =
      FirebaseFirestore.instance.collection('categories');
  static Stream<List<Category>> allCategory() {
    return reference.snapshots().map(
        (event) => event.docs.map((e) => Category.fromJson(e.data())).toList());
  }

  static Future<List<Category>> getData() {
    return FirebaseFirestore.instance
        .collection('categories')
        .get()
        .then((value) {
      return value.docs.map((e) => Category.fromJson(e.data())).toList();
    });
  }

  static Future<int> addData(Map<String, dynamic> data) async {
    await FirebaseFirestore.instance.collection('categories').add(data);
    return 1;
  }
}
