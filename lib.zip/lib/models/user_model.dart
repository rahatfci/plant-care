class User {
  String name;
  String email;
  String imgPath;
  String userType;
  String? address;
  String? phone;
  DateTime createdAt;
  User(
      {required this.name,
      required this.email,
      required this.imgPath,
      required this.userType,
      required this.address,
      required this.phone,
      required this.createdAt});

  Map<String, dynamic> toJson(User user) {
    return {
      'name': user.name,
      'email': user.email,
      'imgPath': user.imgPath,
      'userType': user.userType,
      'address': user.address,
      'phone': user.phone,
      'createdAt': user.createdAt
    };
  }

  User fromJson(data) {
    return User(
        name: data['name'],
        email: data['email'],
        imgPath: data['imgPath'],
        userType: data['userType'],
        address: data['address'],
        phone: data['phone'],
        createdAt: data['createdAt']);
  }
}
