class Category {
  final String id;
  final String name;
  final String imgPath;

  Category({required this.id, required this.name, required this.imgPath});

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'imgPath': imgPath,
    };
  }

  static Category fromJson(data) {
    return Category(
        id: data['id'], name: data['name'], imgPath: data['imgPath']);
  }
}
