class Product {
  final String id;
  final String name;
  final String imgPath;
  final String description;
  final int amount;
  final int discount;
  final int price;

  Product(
      {required this.id,
      required this.name,
      required this.imgPath,
      required this.description,
      required this.amount,
      required this.discount,
      required this.price});

  Map<String, dynamic> toJson(Product product) {
    return {
      'id': product.id,
      'name': product.name,
      'imgPath': product.imgPath,
      'description': product.description,
      'amount': product.amount,
      'discount': product.discount,
      'price': product.price,
    };
  }

  static Product fromJson(data) {
    return Product(
        id: data['id'],
        name: data['name'],
        imgPath: data['imgPath'],
        description: data['description'],
        amount: data['amount'],
        discount: data['discount'],
        price: data['price']);
  }
}
