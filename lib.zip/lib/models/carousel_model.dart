class CarouselCustom {
  final String id;
  final String imgPath;

  CarouselCustom({required this.id, required this.imgPath});

  Map<String, dynamic> toJson(CarouselCustom carousel) {
    return {
      'id': carousel.id,
      'imgPath': carousel.imgPath,
    };
  }

  static CarouselCustom fromJson(data) {
    return CarouselCustom(id: data['id'], imgPath: data['imgPath']);
  }
}
