import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../../../constants.dart';

class Carousel extends StatelessWidget {
  const Carousel({Key? key}) : super(key: key);
  final List<String> imgPaths = const [
    'assets/images/mounten.jpg',
    'assets/images/field.jpg',
    'assets/images/forest.jpg',
  ];
  @override
  Widget build(BuildContext context) {
    return CarouselSlider.builder(
        itemCount: imgPaths.length,
        itemBuilder: (BuildContext context, int itemIndex, int pageViewIndex) =>
            Container(
              width: MediaQuery.of(context).size.width,
              margin: const EdgeInsets.symmetric(horizontal: 3.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                    image: AssetImage(imgPaths[itemIndex]), fit: BoxFit.fill),
                color: kTextColor.withOpacity(.7),
                //borderRadius: BorderRadius.circular(20),
              ),
            ),
        options: CarouselOptions(height: 180, aspectRatio: 15 / 9));
  }
}
