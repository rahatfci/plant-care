import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:plant_watch/screens/settings/components/build_tile.dart';

class Body extends StatelessWidget {
  Body({Key? key}) : super(key: key);
  final User? user = FirebaseAuth.instance.currentUser;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: SingleChildScrollView(
        child: Column(
          children: [
            const Center(
              child: CircleAvatar(
                backgroundImage: AssetImage('assets/images/field.jpg'),
                radius: 50,
              ),
            ),
            const SizedBox(height: 15),
            Text(
              user!.displayName!,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(
              height: 5,
            ),
            Text(
              user!.email!,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(
              height: 15,
            ),
            GridView(
              shrinkWrap: true,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  mainAxisExtent: 110),
              children: [
                buildTile("Total Order", 0xffdc9ba8, Icons.shopping_bag,
                    count: 5),
                buildTile("Total Saved", 0xff92b2a7, Icons.local_offer,
                    count: 420),
                buildTile("Edit Profile", 0xff63a3a8, Icons.edit),
                buildTile("Help & Support", 0xffefbea3, Icons.support),
                const SizedBox(
                  height: 10,
                )
              ],
            ),
            const SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }
}
