import 'package:flutter/material.dart';

import '../../../constants.dart';
import '../../../controllers/category_controller.dart';
import '../../../models/category_model.dart';
import 'build_tile.dart';

class Body extends StatelessWidget {
  const Body({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Category>>(
      future: CategoryController.getData(),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return GridView.builder(
            itemCount: snapshot.data!.length,
            padding: const EdgeInsets.all(15),
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                mainAxisExtent: 110),
            itemBuilder: (context, i) {
              return buildTile(
                  snapshot.data![i].name, snapshot.data![i].imgPath, context,
                  count: 5);
            },
          );
        } else if (snapshot.hasError) {
          return Text('${snapshot.error}');
        } else {
          return const Center(
            child: CircularProgressIndicator(
              color: kPrimaryColor,
            ),
          );
        }
      },
    );
  }
}
