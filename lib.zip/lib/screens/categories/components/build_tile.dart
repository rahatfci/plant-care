import 'package:flutter/material.dart';
import 'package:palette_generator/palette_generator.dart';
import 'package:plant_watch/constants.dart';

Widget buildTile(String text, String image, BuildContext context,
    {int? count}) {
  return Card(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    elevation: 10,
    child: FutureBuilder(
        future: getColor(image),
        builder: (context, AsyncSnapshot<Color> snapshot) {
          if (snapshot.hasData) {
            return Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: snapshot.data),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(count != null ? "$count" : "",
                            style: const TextStyle(
                                color: Color(0xff000000),
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                        CircleAvatar(
                          radius: 25,
                          backgroundImage: NetworkImage(image),
                          backgroundColor: kPrimaryColor,
                        )
                      ],
                    ),
                    Text(text,
                        style: const TextStyle(
                            color: Color(0xff000000),
                            fontSize: 16,
                            fontWeight: FontWeight.bold))
                  ]),
            );
          } else {
            return Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: const Color(0xFFFFFFFF)),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(count != null ? "$count" : "",
                            style: const TextStyle(
                                color: Color(0xff000000),
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                        CircleAvatar(
                          backgroundColor: kPrimaryColor,
                          radius: 25,
                          backgroundImage: NetworkImage(image),
                        )
                      ],
                    ),
                    Text(text,
                        style: const TextStyle(
                            color: Color(0xff000000),
                            fontSize: 16,
                            fontWeight: FontWeight.bold))
                  ]),
            );
          }
        }),
  );
}

Future<Color> getColor(String image) async {
  final PaletteGenerator paletteGenerator =
      await PaletteGenerator.fromImageProvider(NetworkImage(image));
  return paletteGenerator.vibrantColor!.color;
}
